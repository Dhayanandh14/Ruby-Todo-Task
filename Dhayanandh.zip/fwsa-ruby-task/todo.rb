# print ARGV
if ARGV[0]=="help" || ARGV[0]=="usage" || ARGV[0]==nil
    puts "Usage :-"
    puts"$ ./todo add \"todo item\"  # Add a new todo"
    puts"$ ./todo ls               # Show remaining todos"
    puts"$ ./todo del NUMBER       # Delete a todo"
    puts"$ ./todo done NUMBER      # Complete a todo"
    puts"$ ./todo help             # Show usage"
    print"$ ./todo report           # Statistics"
end

if ARGV[0]=="add"
    if(ARGV[1]==nil)
        print "Error: Missing todo string. Nothing added!";
    else
        fo = File.new("todo.txt", "a+");
        fo.syswrite(ARGV[1]);
        fo.write("\n");
        fo.close()
        print "Added todo: \"#{ARGV[1]}\" ";     
    end
end

if ARGV[0] == "ls"
    begin
        fr = File.open("todo.txt","r");
        b = (fr.readlines.map(&:chomp));
        fr.close()
        if b.size == 0
            print "There are no pending todos!"
        else
            b.size.downto(1) do |c|
                sc = c.to_s
                    print "[",sc,"] " , b[b.size-c],"\n"
            end
        end   
    rescue => exception
        print "There are no pending todos!"
    else
        
    end
end

if ARGV[0]=="del"
    delno=ARGV[1]
    if delno==nil
        print "Error: Missing NUMBER for deleting todo."
    else 
        fr = File.open("todo.txt","r");
            b = (fr.readlines.map(&:chomp));
        fr.close();
        delno = ARGV[1].to_i
        if delno <= b.size  and delno != 0
            fo = File.open("todo.txt", "w+");
            b.delete_at(delno-1)
            for i in (0..b.length-1)
                fo.puts(b[i])
            end
            fo.close();
            print "Deleted todo ##{delno}"
        else
            print "Error: todo ##{delno} does not exist. Nothing deleted."
        #    f.open('todo.txt','r')
        end
    end
end

if(ARGV[0]=='done')
    b = IO.readlines("todo.txt", chomp: true)
    if ARGV[1]==nil
        print "Error: Missing NUMBER for marking todo as done."
    else 
        doneno = ARGV[1].to_i
        if doneno <= b.size  and doneno != 0
            fo = File.open("todo.txt", "w+");
            deletedone = b.delete_at(doneno-1)
            for i in (0..b.length-1)
                fo.puts(b[i])
            end
            fo = File.new("done.txt", "a+");
            fo.syswrite(deletedone);
            fo.write("\n");
            fo.close();
            print "Marked todo ##{doneno} as done. "
        else
            print "Error: todo ##{doneno} does not exist."
        end
    end
end

if ARGV[0]=="report"
    t = IO.readlines("todo.txt", chomp: true)
    d = IO.readlines("done.txt", chomp: true)
    print Time.now.strftime("%Y-%m-%d")," ","Pending : ",t.size," ","Completed : ",d.size
end
    




# # if ARGV[0] == "ls"
   
# #     File.open("todo.txt").each do |line|
# #         puts "#{line.rstrip} #{$.}"
# #      end
# end


# if ARGV[0] == "ls"
#     b = IO.readlines("todo.txt")
#         b.to_enum.with_index.reverse_each do |word, index|
#         puts "[#{index+1}] #{word}"
#     end
# end














# input_array=ARGV;
# if(input_array[0]=="usage")
#     puts "$ ./todo add              # Add a new todo"
#     puts "$ ./todo ls               # Show remaining todos"
#     puts "$ ./todo del NUMBER       # Delete a todo"                                                                                                                                                                                   
#     puts "$ ./todo done NUMBER      # Complete a todo"
#     puts "$ ./todo help             # Show usage"
#     puts "$ ./todo report           # Statistics`"

# elsif(input_array[0] == "add")
#     s=input_array[1]
#     exist=false;
#     if(input_array[1]==nil)
#         print "Error: Missing todo string. Nothing added!";
#     else
#         f=File.new("todo.txt","a+");
#         if(true)
#             f.syswrite(s);
#             f.write("\n");
#             exist=true
#         end
#         f.close();
#         if(exist)
#             puts "Added todo: \"#{input_array[1]}\" ";
#         end
#         exist=false
#     end
# end


# elsif(input_array[0] == "ls")
#     f=File.open("todo.txt","r");
#     revline=(f.readlines.map(&:chomp)).reverse;
#     f.close();
#     if(input_array.lengthn== 0)
#       print "There are no pending todos!"
#     else
#         revcnt=revline.size
#         f=File.open("todo.txt");
#         i=revcnt
#         for j in(0..revline.length-1)
#             if(j==revline.length-1)
#               print("[#{i}] #{revline[j]}"")
#             else
#               puts("#[{i}] #{revline[j]}")
#             end
#             i=i-1
#         end
#     end


# elsif(input_array[0] == "done")
#     if(input_array[1] == nil)
#         print "Error: Missing NUMBER for marking todo as done."
#     else
#         num = input_array[1].to_i
#         f=File.open("todo.txt","r");
#         line=(f.readlines.map(&:chomp))
#         done=File.new("done.txt","a");
#         if(num!=0 and num<=line.size)
#             done.puts( "#{Time.now.strftime("%Y-%m-%d")}#{line[num-1]} ");
#             line.delete_at(num-1)
#             f1=File.open("todo.txt","w+");
#             for i in (0..line.length-1)
#                 f1.puts(line[i])
#             end
#             f1.close();
#             print "Marked todo ##{num} as done."
#         else
#             print "Error: todo ##{num} does not exist"
#         end        
#         f1.close();
#         done.close();
#     end
# elsif(input_array[0]=="del")
#     if(input_array[1]==nil)
#         print "Error: Missing NUMBER for deleting todo."
#     else
#         num=input_array[1].to_i
#         f.File.open("todo.txt")
#         line=(f.readlines.map(&:chomp))
#         if(num!=0 and num<=line.size)
#             f.delete_at(num)
#             print "Deleted todo #${num}"
#         else
#             print("Error: todo #${num} does not exist. Nothing deleted.")
#     end
    
# elsif(input_array[0]=="report")
#     f=File.open("todo.txt","r");
#     cnt=(f.readlines.map(&:chomp));
#     d=File.open("todo.txt","r");
#     cntd=(d.readlines.map(&:chomp));
#     puts "#{Time.now.strftime("%Y-%m-%d")} pending: #{cnt} Complete: #{cntd}"
# else
#     print("unexpectd input")
# end



